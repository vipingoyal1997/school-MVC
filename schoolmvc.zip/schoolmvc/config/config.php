<?php




define("HOST","localhost");
define("USER","root");
define("DATABASE","oldschool");
define("PASSWORD","");



?>